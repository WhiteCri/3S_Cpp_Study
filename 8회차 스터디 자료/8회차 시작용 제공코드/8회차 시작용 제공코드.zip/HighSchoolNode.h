#pragma once
#include <iostream>

using std::string;
struct HighSchoolNode{
public:
	string str[11];
	int n[18];
};

#ifndef MAX_STR
#define MAX_STR 10
#endif


#ifndef MAX_NUMBER
#define MAX_NUMBER 18
#endif
