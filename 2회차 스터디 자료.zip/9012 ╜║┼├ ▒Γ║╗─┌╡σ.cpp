#include <iostream>
#include <string.h>
using namespace std;

struct stack{
private:
	char ptr[50];
	int top;
	int Size;
public:
	void initStack();
	int push(char );
	int pop(char *);

	int isFull(void);
	void clearStack(void);
};

void stack::initStack()
//���� �ʱ�ȭ �Լ�
//���ϰ� : ����
//ptr->��� 0,top : 0, Size:50
{

}

int stack::push(char ch){

}

int stack::pop(char* chp){

}

int stack::isFull(){

}

void stack::clearStack(){

}


