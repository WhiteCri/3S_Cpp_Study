#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#define EPSILON 0.00001

typedef struct _info {
	int x;
	int y;
	int r;
}Info;

int result(Info *first, Info * second);

int main(void) {

}
